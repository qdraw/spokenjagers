---
layout: page
title: About
permalink: /about/
---

Een blog voor het school project van Dion van Velde.
Deze blog loopt van februari tot juni 2015 en is onderdeel van mijn opleiding.

Check voor meer werk:
[qdraw.nl](http://qdraw.nl)

